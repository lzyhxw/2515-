// pages/index/login/login.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },

    login(e){
        var userName=e.detail.value["userName"];
        var userPwd=e.detail.value["userPwd"];
        if(userName==""){
            wx.showToast({
              title: '用户名不能为空',
            //   duration: 0,
              icon: "error",
            //   image: '/_my.png',
            //   mask: true,
            //   success: (res) => {},
            //   fail: (res) => {},
            //   complete: (res) => {},
            })
            // wx.showModal({
            //   cancelColor: 'cancelColor',
            //   cancelText: 'cancelText',
            //   confirmColor: 'confirmColor',
            //   confirmText: 'confirmText',
            //   content: 'content',
            //   editable: true,
            //   placeholderText: 'placeholderText',
            //   showCancel: true,
            //   title: 'title',
            //   success: (result) => {},
            //   fail: (res) => {},
            //   complete: (res) => {},
            // })

        }
        
        if(userName=="admin"&&userPwd=="123"){
            console.log("成功");
        }else{
            console.log("失败");
        }
        //服务器    要更改 详情-本地..-不校验合法域名......
        wx.request({
            header: {"Content-Type":"application/x-www-form-urlencoded"},
            url: 'http://192.168.93.1:8080/pet/ajaxLogin',
            data: {userName,userPwd},
            method: "POST",
          //   dataType: dataType,
          //   enableCache: true,
          //   enableChunked: true,
          //   enableHttp2: true,
          //   enableHttpDNS: true,
          //   enableQuic: true,
          //   forceCellularNetwork: true,
          //   httpDNSServiceId: 'httpDNSServiceId',
          //   responseType: responseType,
          //   timeout: 0,
            success: (res) => {
                console.log(res);
                if(res.data==1){
                    console.log("成功")
                }else{
                    console.log("失败")
                }
                
            },
            // fail: (err) => {
            // },
            // complete: (res) => {},
          })
    }
})