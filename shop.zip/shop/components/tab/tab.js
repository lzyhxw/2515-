// components/tab/tab.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        tabList:Array
    },

    /**
     * 组件的初始数据
     */
    data: {
        
    },

    /**
     * 组件的方法列表
     */
    methods: {
        tabClick(e){      
            let id=e.currentTarget.dataset.id;      //当前id

            //调用页面的事件（事件名称，传递参数）
            this.triggerEvent("itemTabClick",id);
        }
    }
})
