Page({
  data: {
    swiperList:[],       //轮播图
    categoryList:[],       //分类
    floorList:[]          //楼层
  },
  /**
   * 页面加载事件
   */
  onLoad() {
    this.getSwiperList();
    this.getCategoryList();
    this.getFloorList();
  },
  getSwiperList(){
    wx.request({
      url: 'https://api-hmugo-web.itheima.net/api/public/v1/home/swiperdata',
      success:(res)=>{
        this.setData({
          swiperList:res.data.message
        })
      }
    })
  },
  getCategoryList(){
    wx.request({
      url: 'https://api-hmugo-web.itheima.net/api/public/v1/home/catitems',
      success:(res)=>{
        this.setData({
          categoryList:res.data.message
        })
      }
    })
  },
  getFloorList(){
    wx.request({
      url: 'https://api-hmugo-web.itheima.net/api/public/v1/home/floordata',
      success:(res)=>{
        console.log(res.data.message)
        this.setData({
          floorList:res.data.message
        })
      }
    })
  }
})
