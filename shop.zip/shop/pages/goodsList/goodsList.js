// pages/goodsList/goodsList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabList:[{
        id:1,                   //主键
        title:"综合",           //显示的文本
        active:true             //选中的状态
    },{
        id:2,               
        title:"销量",
        active:false
    },{
        id:3,               
        title:"价格",
        active:false
    }],
    goodsList:[]
  },
  query:{
    cid:0,          //分类id
    pagenum:1,      //当前页码
    pagesize:10     //每页显示行数
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.query.cid=options.cid;
    this.getGoodsList();
  },
  getGoodsList(){
    wx.request({
      url: 'https://api-hmugo-web.itheima.net/api/public/v1/goods/search',
      data:this.query,
      success:(res)=>{
        console.log(res.data.message.goods)
        this.setData({
          goodsList:[...this.data.goodsList,...res.data.message.goods]
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    //重新加载第一页的数据
    this.setData({
      goodsList:[]
    })
    this.query.pagenum=1;
    this.getGoodsList();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    this.query.pagenum++;
    this.getGoodsList();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  /**
   * 选项卡事件
   */
  itemTabClick(e){
      let id=e.detail;
      let list=this.data.tabList;
      //将当前选中的active改成true，其他改成false      
      list.forEach((item,index)=>item.id==id?item.active=true:item.active=false);
      this.setData({
           tabList:list
      })
  }
})