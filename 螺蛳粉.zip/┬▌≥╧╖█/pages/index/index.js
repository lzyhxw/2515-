// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
   id:1,
   name:"111",
   titleList:[{
    id:1,
    title:"商品推荐"
  },{
    id:2,
    title:"优惠券"
  },{
    id:3,
    title:"评论"
  }],
  goodsList:[]

  },
  queryData:{
    cat_id:1,
    pagenum:1,
    pagesize:10

  },

  // 事件处理函数
  bindViewTap() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad() {
    this.getGoodsList();
  },
  getGoodsList(){
    wx.request({
      url: 'https://api-hmugo-web.itheima.net/api/public/v1/goods/search',
      data:this.queryData,
      success:(res)=>{
        console.log(res);
        console.log(res.data.message.goods);
        this.setData({
          goodsList:[...this.data.goodsList,...res.data.message.goods]
        })
        console.log(this.data.goodsList)
      }
    })
  },

  getTitleId(e){
    // console.log("独守空房");
    console.log(e.detail);
    let id=e.detail;
    this.setData({id:id})
    switch(id){
      case 1:{
      //  console.log(this.queryData.pagenum);
        this.getGoodsList();
      };break;
      case 2:{
        this.setData({name:this.data.titleList[id-1].title});
      };break;
      case 3:{
        this.setData({name:this.data.titleList[id-1].title});
      };break;
    }

  },
  onPullDownRefresh(){
    this.queryData.pagenum=1;
    this.setData({goodsList:[]});
    this.getGoodsList();
  },

  onReachBottom(){
    this.queryData.pagenum++
    this.getGoodsList();
  }
  
})
