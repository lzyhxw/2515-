// components/tab/tab.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    titleList:Array
  },

  /**
   * 组件的初始数据
   */
  data: {
    id:0
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    dj1(e){
      console.log(e.currentTarget.dataset.bj1);
      // console.log(111);
      this.setData({
        id:e.currentTarget.dataset.bj1
      });
      //调用外部
      this.triggerEvent("getTitleId",this.data.id);
      
    }
  }
 
})
